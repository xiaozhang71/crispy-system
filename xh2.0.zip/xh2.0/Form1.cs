using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System;
using System.Data.SqlClient; // ����ʹ�� SQL Server ���ݿ�
using MySql.Data.MySqlClient;

namespace xh2._0
{
    public partial class Form1 : Form
    {
        int k = 1;
        public string xm = "";
        public string zy = "";
        public string yx = "";
        private string chaxun = "where `ѧ��` = @ѧ��";
        private string connectionString1 = "server=localhost;database=AWEINO1;user=root;password=1314.zhang";
        public Form1()
        {
            InitializeComponent();
            kaishi();
            textBox3.Text = xm;
            textBox4.Text = SharedData.Value1;//ѧ��
            textBox6.Text = zy;
            textBox7.Text = yx;
            BLLxh.B_tz myClass = new BLLxh.B_tz();
            string[] sum = myClass.btz(1);

            
            if (sum.Length >= 2)
            {
                textBox8.Text = sum[0];
                textBox1.Text = sum[1];
            }
            else
            {
                textBox8.Text = sum[0];
                // �������鳤�Ȳ��������
            }
        }
        // Declare accstr as a public property in Form1
        private void kaishi()
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString1))
            {
                //string query = $"SELECT * FROM `�γ�` {chaxun};";
                string query = "SELECT * FROM `studentsxx`" + chaxun + ";";
                MySqlCommand command = new MySqlCommand(query, connection);
                command.Parameters.AddWithValue("@ѧ��", SharedData.Value1);
                MySqlDataAdapter adapter = new MySqlDataAdapter(command);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);

                if (dataTable.Rows.Count > 0)
                {
                    xm = dataTable.Rows[0]["����"].ToString();
                    zy = dataTable.Rows[0]["רҵ"].ToString();
                    yx = dataTable.Rows[0]["��������"].ToString();
                }

            }
        }



        private void button1_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();  
            form2.Show();               
            this.Hide();
        }
        
        private void button2_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();  
            form3.Show();               
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form4 form4 = new Form4();  
            form4.Show();               
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form5 form5 = new Form5();  
            form5.Show();               
            this.Hide();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Form6 form6 = new Form6();
            form6.Show();
            this.Hide();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Form7 form7 = new Form7();
            form7.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form8 form8 = new Form8();
            form8.Show();
            this.Hide();
        }
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {

            // �رյ�ǰ���ڲ��˳�����
            Application.Exit();

        }

        private void button9_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            Form10 form10 = new Form10();
            form10.Show();
            
        }

        private void button8_Click(object sender, EventArgs e)
        {

        }

        

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            Form11 form11 = new Form11();
            form11.Show();
            this.Hide();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {


        }

        private void button14_Click(object sender, EventArgs e)
        {
            BLLxh.B_tz myClass = new BLLxh.B_tz();
            k++;
            
            string[] sum = myClass.btz(k);

            if (sum.Length >= 2)
            {
                textBox8.Text = sum[0];
                textBox1.Text = sum[1];
            }
            else
            {
                textBox8.Text = sum[0];
                // �������鳤�Ȳ��������
            }
        }

        private void button15_Click(object sender, EventArgs e)
        {
            BLLxh.B_tz myClass = new BLLxh.B_tz();
            k--;

            string[] sum = myClass.btz(k);

            if (sum.Length >= 2)
            {
                textBox8.Text = sum[0];
                textBox1.Text = sum[1];
            }
            else
            {
                textBox8.Text = sum[0];
                // �������鳤�Ȳ��������
            }
        }
    }
    public static class SharedData
    {
        public static string Value1 { get; set; }
        public static int Value2 { get; set; }
        
    }
}
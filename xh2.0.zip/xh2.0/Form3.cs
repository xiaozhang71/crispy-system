﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace xh2._0
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();  // 创建Form2实例
            form1.Show();               // 显示Form2窗体
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();  // 创建Form2实例
            form1.Show();               // 显示Form2窗体
            this.Hide();
        }
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {

            // 关闭当前窗口并退出程序
            Application.Exit();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form12 form12 = new Form12();  // 创建Form2实例
            form12.Show();               // 显示Form2窗体
            this.Hide();
        }
    }
}

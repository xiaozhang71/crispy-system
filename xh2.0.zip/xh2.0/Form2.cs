﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System;
using System.Data.SqlClient; // 假设使用 SQL Server 数据库
using MySql.Data.MySqlClient;


namespace xh2._0
{
    public partial class Form2 : Form
    {
        private string chaxun = "where `学号` = @学号";
        private string connectionString1 = "server=localhost;database=AWEINO1;user=root;password=1314.zhang";
        public Form2()
        {
            InitializeComponent();
            kaicha();
        }
        private void kaicha()
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString1))
            {
                //string query = $"SELECT * FROM `课程` {chaxun};";
                string query = "SELECT * FROM `studentsxx`" + chaxun + ";";
                MySqlCommand command = new MySqlCommand(query, connection);
                command.Parameters.AddWithValue("@学号", SharedData.Value1);
                MySqlDataAdapter adapter = new MySqlDataAdapter(command);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);

                if (dataTable.Rows.Count > 0)
                {
                    textBox2.Text = dataTable.Rows[0]["姓名"].ToString();
                    textBox4.Text = dataTable.Rows[0]["专业"].ToString();
                    textBox7.Text = dataTable.Rows[0]["电子邮箱"].ToString();
                    textBox12.Text = dataTable.Rows[0]["校区"].ToString();
                    textBox1.Text = dataTable.Rows[0]["学院"].ToString();
                    textBox9.Text = dataTable.Rows[0]["学号"].ToString();
                    textBox10.Text = dataTable.Rows[0]["辅导员"].ToString();
                    textBox11.Text = dataTable.Rows[0]["号码"].ToString();
                    textBox5.Text = dataTable.Rows[0]["专业方向"].ToString();
                    textBox6.Text = dataTable.Rows[0]["联系方式"].ToString();
                    textBox8.Text = dataTable.Rows[0]["政治面貌"].ToString();
                    textBox3.Text = dataTable.Rows[0]["年级"].ToString();
                }

            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();  // 创建Form2实例
            form1.Show();               // 显示Form2窗体
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();  // 创建Form2实例
            form3.Show();               // 显示Form2窗体
            this.Hide();
        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void textBox12_TextChanged(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void textBox11_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {

            // 关闭当前窗口并退出程序
            Application.Exit();

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System;
using System.Data.SqlClient; // 假设使用 SQL Server 数据库

using System.Collections.Generic;
using MySqlConnector;
namespace xh2._0
{
    public partial class Form9 : Form
    {
        private string chaxun = "";
        private string connectionString = "server=localhost;database=AWEINO1;user=root;password=1314.zhang;Allow User Variables=true;";
        public Form9()
        {
            InitializeComponent();
            xs();
        }


        

        private void button3_Click(object sender, EventArgs e)
        {
            xs();
        }
        private bool isPasswordVisible = false;
        public void xs()
        {
            if (isPasswordVisible)
            {
                textBox2.PasswordChar = '*';
                isPasswordVisible = false;
            }
            else
            {
                textBox2.PasswordChar = '\0'; // Set PasswordChar to null to show the actual characters
                isPasswordVisible = true;
            }
        }
        public string kk = "";
        string d1 = "";
        string d2 = "";
        private void button1_Click(object sender, EventArgs e)
        {   
            d1 = textBox1.Text;
            d2 = textBox2.Text;
            bool result = BLLxh.Class1.InsertData(d1, d2);
            if (result)
            {   //In button1_Click event of Form9
                Form10 form10 = new Form10();
                form10.Show();
                Form1 form1 = new Form1();
                //Assign the value from from9.kk to accstr
                SharedData.Value1 = kk;
                form1.Show();
                this.Hide();
            }
            if (!result)
            { // 登录失败，弹出提示
                MessageBox.Show("登录失败，请检查账号密码是否错误。", "登录失败", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

            private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {

            // 关闭当前窗口并退出程序
            Application.Exit();

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            kk = textBox1.Text;
            SharedData.Value1 = kk;
        }
    }
}

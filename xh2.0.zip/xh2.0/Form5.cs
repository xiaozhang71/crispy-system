﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Data.SqlClient; // 假设使用 SQL Server 数据库
using System.Windows;
using MySqlConnector;

namespace xh2._0
{
    
    public partial class Form5 : Form
    {   private int a = -1;
        int sum = 1;
        public string connectionString = "server=localhost;database=AWEINO1;user=root;password=1314.zhang;Allow User Variables=true;";
        public Form5()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            a *= -1;
            if (a == 1) { button2.Text = "取消申请";}
            else if (a == -1) { button2.Text = "申请指导"; }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {

            // 关闭当前窗口并退出程序
            Application.Exit();

        }
        int arr = 0;
        private void button4_Click(object sender, EventArgs e)
        {

            sum++;
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                //string query = $"SELECT * FROM `课程` {chaxun};";
                string query = "SELECT * FROM tech WHERE 工号 = @id;";
                MySqlCommand command = new MySqlCommand(query, connection);
                command.Parameters.AddWithValue("@id", sum);
                MySqlDataAdapter adapter = new MySqlDataAdapter(command);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);

                if (dataTable.Rows.Count > 0)
                {
                    textBox2.Text = dataTable.Rows[0]["姓名"].ToString();
                    textBox12.Text = dataTable.Rows[0]["校区"].ToString();
                    textBox1.Text = dataTable.Rows[0]["学院"].ToString();
                    textBox5.Text = dataTable.Rows[0]["专业方向"].ToString();
                    textBox6.Text = dataTable.Rows[0]["联系方式"].ToString();
                    textBox7.Text = dataTable.Rows[0]["邮箱"].ToString();
                    textBox3.Text = dataTable.Rows[0]["个人简介"].ToString();
                }

            }
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                //string query = $"SELECT * FROM `课程` {chaxun};";
                string query = "SELECT * FROM tech WHERE 工号 = @id;";
                MySqlCommand command = new MySqlCommand(query, connection);
                command.Parameters.AddWithValue("@id", sum);
                MySqlDataAdapter adapter = new MySqlDataAdapter(command);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);

                if (dataTable.Rows.Count > 0)
                {
                    textBox2.Text = dataTable.Rows[0]["姓名"].ToString();
                    textBox12.Text = dataTable.Rows[0]["校区"].ToString();
                    textBox1.Text = dataTable.Rows[0]["学院"].ToString();
                    textBox5.Text = dataTable.Rows[0]["专业方向"].ToString();
                    textBox6.Text = dataTable.Rows[0]["联系方式"].ToString();
                    textBox7.Text = dataTable.Rows[0]["邮箱"].ToString();
                    textBox3.Text = dataTable.Rows[0]["个人简介"].ToString();
                }

            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            sum--;
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                //string query = $"SELECT * FROM `课程` {chaxun};";
                string query = "SELECT * FROM tech WHERE 工号 = @id;";
                MySqlCommand command = new MySqlCommand(query, connection);
                command.Parameters.AddWithValue("@id", sum);
                MySqlDataAdapter adapter = new MySqlDataAdapter(command);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);

                if (dataTable.Rows.Count > 0)
                {
                    textBox2.Text = dataTable.Rows[0]["姓名"].ToString();
                    textBox12.Text = dataTable.Rows[0]["校区"].ToString();
                    textBox1.Text = dataTable.Rows[0]["学院"].ToString();
                    textBox5.Text = dataTable.Rows[0]["专业方向"].ToString();
                    textBox6.Text = dataTable.Rows[0]["联系方式"].ToString();
                    textBox7.Text = dataTable.Rows[0]["邮箱"].ToString();
                    textBox3.Text = dataTable.Rows[0]["个人简介"].ToString();
                }

            }
        }
    }
}

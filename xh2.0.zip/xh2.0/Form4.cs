﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System;
using System.Data.SqlClient; // 假设使用 SQL Server 数据库
using MySql.Data.MySqlClient;
namespace xh2._0
{
    
    public partial class Form4 : Form
    {
        private string chaxun = "";
        private string connectionString = "server=localhost;database=AWEINO1;user=root;password=1314.zhang";
        public Form4()
        {
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            LoadTechData();
        }
        
        private void button2_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();  // 创建Form2实例
            form1.Show();               // 显示Form2窗体
            this.Hide();
        }

        private void vScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form5 form5 = new Form5();  // 创建Form2实例
            form5.Show();               // 显示Form2窗体
            this.Hide();
        }
        private void LoadTechData()
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                string query = $"SELECT * FROM tech {chaxun};";

                MySqlCommand command = new MySqlCommand(query, connection);
                MySqlDataAdapter adapter = new MySqlDataAdapter(command);
                DataTable dataTable = new DataTable();

                adapter.Fill(dataTable);

                dataGridView1.DataSource = dataTable;
            }
        }

        private void button1_Click(object sender, EventArgs e)//查询键
        {
            chaxun = "where `姓名` =" + textBox1.Text;
            LoadTechData();
        }
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {

            // 关闭当前窗口并退出程序
            Application.Exit();

        }
    }
}
//SELECT * FROM  tech
//WHERE `姓名` = '张三'
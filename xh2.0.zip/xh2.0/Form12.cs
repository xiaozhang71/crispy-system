﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System;
using System.Data.SqlClient; // 假设使用 SQL Server 数据库
using MySql.Data.MySqlClient;

namespace xh2._0
{
    public partial class Form12 : Form
    {
        
        private string connectionString1 = "server=localhost;database=AWEINO1;user=root;password=1314.zhang";
        public Form12()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();  // 创建Form2实例
            form1.Show();               // 显示Form2窗体
            this.Hide();
        }
        /*UPDATE Notifications
        SET Title = 'New Title'
        WHERE ID = 1;*/
        private void button1_Click(object sender, EventArgs e)
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString1))
            {
                //string query = $"SELECT * FROM `课程` {chaxun};";
                string query = "UPDATE student_accounts SET 密码 = "+ textBox2.Text+ " WHERE 学号 = @学号 and 密码=" + textBox1.Text+"; ";
                MySqlCommand command = new MySqlCommand(query, connection);
                command.Parameters.AddWithValue("@学号", SharedData.Value1);
                MySqlDataAdapter adapter = new MySqlDataAdapter(command);
                DataTable dataTable = new DataTable();
               
                Form9 form9 = new Form9();  // 创建Form2实例
                form9.Show();               // 显示Form2窗体
                this.Hide();


            }
        }
    }
}

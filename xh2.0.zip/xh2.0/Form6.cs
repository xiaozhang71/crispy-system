﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System;
using System.Data.SqlClient; // 假设使用 SQL Server 数据库
using MySql.Data.MySqlClient;

namespace xh2._0
{
    public partial class Form6 : Form
    {
        private string chaxun = "";
        private string connectionString1 = "server=localhost;database=AWEINO1;user=root;password=1314.zhang";
        public Form6()
        {
            InitializeComponent();
            LoadTechData1();
        }

        private void Form6_Load(object sender, EventArgs e)
        {
            
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void LoadTechData1()
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString1))
            {
                //string query = $"SELECT * FROM `课程` {chaxun};";
                string query = "SELECT * FROM `课程`;";
                MySqlCommand command = new MySqlCommand(query, connection);
                MySqlDataAdapter adapter = new MySqlDataAdapter(command);
                DataTable dataTable = new DataTable();

                adapter.Fill(dataTable);

                dataGridView11.DataSource = dataTable;
            }
        }


        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            chaxun = "where `学院` =" + comboBox1.Text;
            LoadTechData1();
        }
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {

            // 关闭当前窗口并退出程序
            Application.Exit();

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace xh2._0
{
    public class SQLDBhelper : IDisposable
    {
        private string connectionString;
        private MySqlConnection connection;

        public SQLDBhelper(string connectionString)
        {
            this.connectionString = connectionString;
            Connect();
        }

        public MySqlConnection Connection
        {
            get { return connection; }
        }

        public void Connect()
        {
            connection = new MySqlConnection(connectionString);
            connection.Open();
        }

        public int ExecuteBatchInsert(string insertQuery, List<MySqlParameter[]> parametersList)
        {
            using (MySqlCommand command = new MySqlCommand(insertQuery, connection))
            {
                using (MySqlTransaction transaction = connection.BeginTransaction())
                {
                    try
                    {
                        foreach (MySqlParameter[] parameters in parametersList)
                        {
                            command.Parameters.Clear(); // 清除之前的参数

                            // 添加参数到命令对象
                            foreach (MySqlParameter parameter in parameters)
                            {
                                command.Parameters.Add(parameter);
                            }

                            // 执行命令
                            int rowsAffected = command.ExecuteNonQuery();

                            // 根据需要处理受影响的行数等信息
                            // ...
                        }

                        transaction.Commit();

                        return parametersList.Count;
                    }
                    catch (Exception ex)
                    {
                        // 处理异常并回滚事务（如果需要）
                        transaction.Rollback();
                        MessageBox.Show("发生错误：" + ex.Message);
                        return 0; // 返回受影响的行数
                    }
                }
            }
        }

        public void Close()
        {
            // 关闭数据库连接的逻辑
            if (connection != null && connection.State == System.Data.ConnectionState.Open)
            {
                connection.Close();
                connection = null;
            }
        }

        // 在 SQLDBhelper 类的 Dispose() 方法中调用 Close() 方法
        public void Dispose()
        {
            // 实现 IDisposable 接口的 Dispose 方法，确保资源释放等清理工作
            Close();
        }






    }
}

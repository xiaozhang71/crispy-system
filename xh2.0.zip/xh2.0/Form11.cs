﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace xh2._0
{
    public partial class Form11 : Form
    {
        public Form11()
        {
            InitializeComponent();
        }

        private void Form11_Load(object sender, EventArgs e)
        {
            BLLxh.chaxunxiaozu myClass = new BLLxh.chaxunxiaozu();
            string[] ss = myClass.chaxundata(SharedData.Value1); ;

            textBox1.Text = ss[0];
            textBox2.Text = ss[1];
            textBox3.Text = ss[2];
            textBox4.Text = ss[3];
            textBox5.Text = ss[4];
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }
    }
}

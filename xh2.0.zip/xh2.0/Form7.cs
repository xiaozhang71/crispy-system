﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System;
using System.Data.SqlClient; // 假设使用 SQL Server 数据库
using MySql.Data.MySqlClient;

namespace xh2._0
{
    public partial class Form7 : Form
    {
        private string chaxun = "";
        private string connectionString1 = "server=localhost;database=AWEINO1;user=root;password=1314.zhang";
        public Form7()
        {
            InitializeComponent();
            LoadTechData1();
        }
        private void LoadTechData1()
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString1))
            {
                //string query = $"SELECT * FROM `课程` {chaxun};";
                string query = "SELECT * FROM `xiaozu`;";
                MySqlCommand command = new MySqlCommand(query, connection);
                MySqlDataAdapter adapter = new MySqlDataAdapter(command);
                DataTable dataTable = new DataTable();

                adapter.Fill(dataTable);

                dataGridView11.DataSource = dataTable;
            }
        }

        private void Form7_Load(object sender, EventArgs e)
        {

        }
        private string chaxun1 = "";
        private string chaxun2 = "";
        private string chaxun3 = "";
        private void LoadTechData2()
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString1))
            {
                //string query = $"SELECT * FROM `课程` {chaxun};";
                string query = "SELECT * FROM `xiaozu`"+chaxun+";";
                MySqlCommand command = new MySqlCommand(query, connection);
                MySqlDataAdapter adapter = new MySqlDataAdapter(command);
                DataTable dataTable = new DataTable();

                adapter.Fill(dataTable);
                // 复制查询结果到变量**************************************************************************
                chaxun1 = dataTable.Rows[2]["组员"].ToString() ;
                chaxun2 = dataTable.Rows[3]["组员"].ToString() ;
                chaxun3 = dataTable.Rows[4]["组员"].ToString();
                dataGridView11.DataSource = dataTable;
            }
        }
        private void button3_Click(object sender, EventArgs e)//查询
        {
            chaxun = "where `组名` =" + textBox1.Text;
            LoadTechData2();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form8 form8 = new Form8();
            form8.Show();
            this.Hide();
        }
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {

            // 关闭当前窗口并退出程序
            Application.Exit();

        }

        private void button4_Click(object sender, EventArgs e)
        {   string s= SharedData.Value1;
            string s2 = "";
            string z2 = "";
            string z3 = "";
            string z4 = "";
            string chaxun = "where `组名` = @学号";
            //using (MySqlConnection connection = new MySqlConnection(connectionString1))
            //{
            //    //string query = $"SELECT * FROM `课程` {chaxun};";
            //    string query = "SELECT * FROM `xiaozu`;" + "where `组名` =" + textBox1.Text + ";";
            //    MySqlCommand command = new MySqlCommand(query, connection);
            //    MySqlDataAdapter adapter = new MySqlDataAdapter(command);
            //    DataTable dataTable = new DataTable();

            //    adapter.Fill(dataTable);

            //    dataGridView11.DataSource = dataTable;
            //}
            using (MySqlConnection connection = new MySqlConnection(connectionString1))
            {
                //string query = $"SELECT * FROM `课程` {chaxun};";
                string query = "SELECT * FROM `studentsxx`" + chaxun + ";";
                MySqlCommand command = new MySqlCommand(query, connection);
                command.Parameters.AddWithValue("@学号", SharedData.Value1);
                MySqlDataAdapter adapter = new MySqlDataAdapter(command);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);

                if (dataTable.Rows.Count > 0)
                {
                    s2 = dataTable.Rows[0]["姓名"].ToString();
                    
                }

            }
            using (MySqlConnection connection = new MySqlConnection(connectionString1))
            {
                //string query = $"SELECT * FROM `课程` {chaxun};";
                string query = "SELECT * FROM `studentsxx`" + chaxun + ";";
                MySqlCommand command = new MySqlCommand(query, connection);
                command.Parameters.AddWithValue("@学号", textBox1.Text);
                MySqlDataAdapter adapter = new MySqlDataAdapter(command);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);

                if (dataTable.Rows.Count > 0)
                {
                    z2 = dataTable.Rows[0]["组员2"].ToString();
                    z3 = dataTable.Rows[0]["组员3"].ToString();
                    z4 = dataTable.Rows[0]["组员4"].ToString();
                }

            }
            string connectionString = "server=localhost;database=AWEINO1;user=root;password=1314.zhang";
            string query1 = "";
            if (z2 == "") {
                query1 = "INSERT INTO xiaozu (组员2) VALUES (@Data1)  WHERE 组名 = " + textBox1.Text + "; ";
               
            }
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                connection.Open();
                
                using (MySqlCommand command = new MySqlCommand(query1, connection))
                {
                    command.Parameters.AddWithValue("@Data1", s2);
                    
                    command.ExecuteNonQuery();
                }
            }
        }








    }
}

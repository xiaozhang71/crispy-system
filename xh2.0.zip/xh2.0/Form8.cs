﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System;
using System.Data.SqlClient; // 假设使用 SQL Server 数据库

using System.Collections.Generic;


using MySqlConnector;
namespace xh2._0
{
    public partial class Form8 : Form
    {
        private string chaxun = "where xiaozuid=0";
        private string connectionString = "server=localhost;database=AWEINO1;user=root;password=1314.zhang;Allow User Variables=true;";
        private string zuming="";
        
        private string connectionString1 = "server=localhost;database=AWEINO1;user=root;password=1314.zhang";
        
        

        
        public Form8()
        {
            InitializeComponent();
        }

        private void Form8_Load(object sender, EventArgs e)
        {
            LoadTechData();
            zuming = textBox1.Text;
            
            
            
        }
        private void LoadTechData()
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                string query = $"SELECT * FROM weizudui {chaxun};";

                MySqlCommand command = new MySqlCommand(query, connection);
                MySqlDataAdapter adapter = new MySqlDataAdapter(command);
                DataTable dataTable = new DataTable();

                adapter.Fill(dataTable);

                dataGridView11.DataSource = dataTable;
            }
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }
        string t1 = "";
        string t2 = "";
        string t3 = "";
        private void label1_Click(object sender, EventArgs e)
        {

        }



        /*private void button1_Click(object sender, EventArgs e)
        {
            // 创建SQLDBhelper实例
            using SQLDBhelper db_helper = new SQLDBhelper(connectionString);

            try
            {
                // 连接到数据库
                db_helper.Connect();

                // 队伍名和学生名字数据
                string teamName = textBox1.Text;
                List<string> studentNames = new List<string>() { textBox5.Text, textBox3.Text, textBox2.Text, textBox4.Text };

                // 插入数据的SQL语句和参数
                string insertQuery = "INSERT INTO xiaozu (组名, 组员1, 组员2, 组员3, 组员4)" +
                     "VALUES (@team_name, @student1, @student2, @student3, @student4)";
                // 执行批量插入操作
                int rowsAffected = db_helper.ExecuteBatchInsert(insertQuery, studentNames.Select((studentName, index) =>new MySqlParameter[]
                {
                    new MySqlParameter("team_name", teamName),
                    new MySqlParameter($"student{index+1}", studentName)
                }).ToList());

                MessageBox.Show($"成功插入 {rowsAffected} 行数据");
            }
            catch (Exception ex)
            {
                MessageBox.Show("发生错误：" + ex.Message);
            }
            finally
            {
                // 关闭数据库连接
                db_helper.Close();
            }
        }*/
        private void button1_Click(object sender, EventArgs e)
        {
            // 队伍名和学生名字数据
            string teamName = textBox1.Text;
            List<string> studentNames = new List<string>() { textBox5.Text,t1,t2,t3};
            try
            {
                // 构建插入的 SQL 查询语句
                string insertQuery = "INSERT INTO xiaozu (组名, 组员1, 组员2, 组员3, 组员4) VALUES(@team_name, @student1, @student2, @student3, @student4)";
                // 连接到数据库
                using (MySqlConnection connection = new MySqlConnection(connectionString))
                {
                    connection.Open();
                    // 创建 MySqlCommand 对象
                    using (MySqlCommand command = new MySqlCommand())
                    {
                        command.Connection = connection;
                        command.CommandText = insertQuery;
                        // 添加参数到命令
                        command.Parameters.AddWithValue("@team_name", teamName);
                        command.Parameters.AddWithValue("@student1", studentNames[0]);
                        command.Parameters.AddWithValue("@student2", studentNames[1]);
                        command.Parameters.AddWithValue("@student3", studentNames[2]);
                        command.Parameters.AddWithValue("@student4", studentNames[3]);

                        // 开启事务
                        using (MySqlTransaction transaction = connection.BeginTransaction())
                        {
                            command.Transaction = transaction;
                            try
                            {
                                // 执行插入操作
                                command.ExecuteNonQuery();

                                // 提交事务
                                transaction.Commit();
                                MessageBox.Show("成功插入 1 行数据");
                            }
                            catch (Exception ex)
                            {
                                // 回滚事务
                                transaction.Rollback();
                                MessageBox.Show("发生错误：" + ex.Message);
                            }
                        }
                    }
                }
                // 刷新数据表格
                LoadTechData();
            }
            catch (Exception ex)
            {
                MessageBox.Show("发生错误：" + ex.Message);
            }
            using (MySqlConnection connection = new MySqlConnection(connectionString1))
            {
                string query = "SELECT * FROM `weizudui` WHERE name = @studentName";
                MySqlCommand command = new MySqlCommand(query, connection);
                command.Parameters.AddWithValue("@studentName", textBox3.Text);
                MySqlDataAdapter adapter = new MySqlDataAdapter(command);
                //textBox5.Text,t1,t2,t3
            }

        }
        int k1 = 0;
        int k2 = 0;
        private void button4_Click(object sender, EventArgs e)
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString1))
            {
                string query = "SELECT * FROM `weizudui` WHERE name = @studentName";
                MySqlCommand command = new MySqlCommand(query, connection);
                command.Parameters.AddWithValue("@studentName", textBox3.Text);
                MySqlDataAdapter adapter = new MySqlDataAdapter(command);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);

                if (dataTable.Rows.Count > 0)
                {
                    dataGridView11.DataSource = dataTable;
                    k2 = 0;
                }
                else
                {
                    MessageBox.Show("No such person or already in a team!");
                    k2 = 1;
                }
            }
            if (k2 == 0) { 
            if (k1 == 0)
            {t1 = textBox3.Text; textBox2.Text = textBox2.Text + textBox3.Text + ","; textBox3.Text = ""; }
            else if (k1 == 1)
            {t2 = textBox3.Text; textBox2.Text = textBox2.Text + textBox3.Text + ","; textBox3.Text = ""; }
            else if (k1 == 2) 
            {t3 = textBox3.Text; textBox2.Text = textBox2.Text + textBox3.Text; textBox3.Text = ""; }
            k1++;}
            
        }


        private void button3_Click(object sender, EventArgs e)
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                string query = $"SELECT * FROM weizudui {chaxun};";

                MySqlCommand command = new MySqlCommand(query, connection);
                MySqlDataAdapter adapter = new MySqlDataAdapter(command);
                DataTable dataTable = new DataTable();

                adapter.Fill(dataTable);

                dataGridView11.DataSource = dataTable;
            }
        }
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            
                // 关闭当前窗口并退出程序
                Application.Exit();
            
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView11_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        
        
    }
}
